This project applied KNN and Euclidean distance as a baseline for re-identification.
Moreover three advanced method applied to improved the result

Folder 'RE-ID_Programming_wc618_xl918' contains 'main.py', 'README.txt', and a folder 'code'.

'main.py' is the 'demo' file, you can run all algorithms in 'main.py', but you only can get the result without
seeing the detailed code of each alogrithm. 

If you want to check and read the detailed code of each algorithm you read the files in the Folder "code"
There are five re-identification approaches in the Folder "code":

1. knn_euclidean : the code of the baseline approach 

2. kmeans_knn : the code of the additional baseline, which incorporates kmeans.

3. ma_covariance : the code of using the original Mahalanobis distance  

4. lmnn : the code of using large margin nearest neighbor classification

5. lmnn_re_ranking : the code of combining re-ranking with LMNN



About the requirement of the data:
#       train_idx: the index of training set
#                  Dimension : (train_M, 1)
#       gallery_idx: the index of gallery set
#                  Dimension : (gallery_M, 1)
#       query_idx: the index of query set 
#                  Dimension : (query_M, 1)          
#       train_idx: the index of training set
#                  Dimension : (train_M, 1)
#       labels: the label of all datas (contains training set, gallery set and query set)
#                  Dimension : (train_M + gallery_M + query_M, 1)
#       cam_label: the label of the camera of each image 
#                  Dimension : (train_M + gallery_M + query_M, 1)          
#       features: the features of each image (contains training set, gallery set and query set)
#                  Dimension : (train_M + gallery_M + query_M, the number of features) 