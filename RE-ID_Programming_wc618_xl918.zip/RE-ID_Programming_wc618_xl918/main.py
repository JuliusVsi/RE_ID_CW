import json
import numpy as np
from scipy.io import loadmat
import matplotlib.pyplot as plt

import sys
sys.path.append('.\\Code')
from Code.knn_euclidean import KNN_baseline
from Code.kmeans_knn import KNN_KMEANS
from Code.ma_covariance import Ma_dis_covariance
from Code.lmnn import LMNN_Metric_Learning
from Code.lmnn_re_ranking import Re_ranking_Lmnn
np.set_printoptions(edgeitems = 6)

#################### Load the data ####################
# when loading the data into the programme, please make sure that
# the path of files and the name of files is correct
# 
# Data:
#       train_idx: the index of training set
#                  Dimension : (train_M, 1)
#       gallery_idx: the index of gallery set
#                  Dimension : (gallery_M, 1)
#       query_idx: the index of query set 
#                  Dimension : (query_M, 1)          
#       train_idx: the index of training set
#                  Dimension : (train_M, 1)
#       labels: the label of all datas (contains training set, gallery set and query set)
#                  Dimension : (train_M + gallery_M + query_M, 1)
#       cam_label: the label of the camera of each image 
#                  Dimension : (train_M + gallery_M + query_M, 1)          
#       features: the features of each image (contains training set, gallery set and query set)
#                  Dimension : (train_M + gallery_M + query_M, the number of features) 
#
data = loadmat('cuhk03_new_protocol_config_labeled.mat')

train_idx = data['train_idx'].flatten().reshape(-1, 1)
train_idx = train_idx - 1
gallery_idx = data['gallery_idx'].flatten().reshape(-1, 1)
gallery_idx = gallery_idx - 1
query_idx = data['query_idx'].flatten().reshape(-1, 1)
query_idx = query_idx - 1


labels = data['labels'].flatten().reshape(-1, 1)
cam_label = data['camId'].flatten().reshape(-1, 1)
filelist = data['filelist'].flatten().reshape(-1, 1)

with open('feature_data.json', 'r') as f:
    features = json.load(f)
features = np.asarray(features)

#################### KNN_Baseline ####################
# Baseline Approach (KNN + Euclidean Distance)
# All the necessary arguments is just the data
# Therefore, you can directly run KNN Baseline algorithm
########################################################
print('################# KNN Baseline Algorithm #################')
score_base, M_A_P_base, Time_consume_base =\
 KNN_baseline(cam_label, gallery_idx, labels, query_idx, train_idx, features)

print('M_A_P_base = ', M_A_P_base)
print('Time_KNN_base = ', Time_consume_base)

rank_num = np.arange(10)
rank_socre_base = np.mean(score_base, 0)
print('rank_score_baseline = ', rank_socre_base)
plt.figure(1)
plt.grid()
plt.plot(rank_num + 1,rank_socre_base, '-or')
plt.title('@rank_K using kNN baseline')
plt.xlabel('K')
plt.ylabel('rank')

#################### KNN_Kmeans ####################
# the basic argument of KNN + Kmeans approach is the same,
# but two additional arguments are necessary
# 
# Additional arguments:
#       num_classes: how many classses you would separated to 
#                  Type : int
#       seed: the random seed for initialization
#                  Type : int
#                  Explanation : Seed is an optional argument. 
#                  Seed is set for generate same initialization when running the programme.
#                  If you don't set it, the algorithm will randomly initialize the centers.
########################################################
print('################# KNN + Kmeans Algorithm #################')
num_classes = 2
score_kmeans, M_A_P_kmeans, Time_consume_kmeans = \
KNN_KMEANS(cam_label, gallery_idx, labels, \
           query_idx, train_idx, features, num_classes, seed=1)

print('M_A_P_kmeans = ', M_A_P_kmeans)
print('Time_consume_kmeans = ', Time_consume_kmeans)

rank_num = np.arange(10)
rank_socre = np.mean(score_kmeans, 0)
print('rank_score_kmeans = ', rank_socre)
plt.figure(2)
plt.grid()
plt.plot(rank_num + 1,rank_socre, '-o',\
         rank_num + 1, rank_socre_base, '-o')
plt.title('@rank_K comparison: kmeans+kNN and kNN baseline')
plt.xlabel('K')
plt.ylabel('rank')

#################### Covariance_Mahalobians_Distance ####################
# All the necessary arguments is just the data
# Therefore, you can directly run Mahalobians Distance with covariance
########################################################
print('################# Covariance_Mahalobians_Distance Algorithm #################')
score_cov, M_A_P_cov, Time_consume_cov =\
Ma_dis_covariance(cam_label, gallery_idx, labels, query_idx, train_idx, features)

print('M_A_P_cov = ', M_A_P_cov)
print('Time_consume_cov = ', Time_consume_cov)

rank_num = np.arange(10)
rank_socre = np.mean(score_cov, 0)
print('rank_score_Ma_Cov = ', rank_socre)
plt.figure(3)
plt.grid()
plt.plot(rank_num + 1,rank_socre, '-o',\
         rank_num + 1, rank_socre_base, '-o')
plt.title('@rank_K comparison: KNN using Mahalanobis distance and KNN baseline')
plt.xlabel('K')
plt.ylabel('rank')

#################### Lmnn_Metric_Learning ####################
# the basic argument of Lmnn_Metric_Learning is the same,
# but some additional arguments are necessary
# 
# Additional arguments:
#       num_traget: how many neighbours you would choose as the traget 
#                  Type : int
#       mu: the weights of pulling terms in the same set and pushing terms in the different set.
#                  Type : float or double
#       k_for_kNN: the k value in the KNN
#                  Type : int
#       alpha: the learning rate of the metric learning
#                  Type : float or double
#       max_iter: the number of iteration
#                  Type : int
########################################################
print('################# Lmnn_Metric_Learning Algorithm #################')
options_lmnn ={'num_traget' : 5, 
               'max_iter' : 2,
               'alpha' : 0.045,
               'mu' : 0.5,
               'k_for_kNN' : 10}

score_lmnn, M_A_P_lmnn, Time_consume_lmnn =\
LMNN_Metric_Learning(cam_label, gallery_idx, labels,\
                    query_idx, train_idx, features, options_lmnn)

print('M_A_P_lmnn = ', M_A_P_lmnn)
print('Time_consume_lmnn = ', Time_consume_lmnn)

rank_num = np.arange(10)
rank_socre = np.mean(score_lmnn, 0)
print('rank_score_Ma_Lmnn = ', rank_socre)
plt.figure(4)
plt.grid()
plt.plot(rank_num + 1,rank_socre, '-o',\
         rank_num + 1, rank_socre_base, '-o')
plt.title('@rank_K comparison: KNN using LMNN metric learning and KNN baseline')
plt.xlabel('K')
plt.ylabel('rank')

#################### Lmnn_plus_Re-ranking ####################
# the basic argument of Lmnn plus Re-ranking is the same,
# but some additional arguments are necessary
# 
# Additional arguments:
#       num_traget: how many neighbours you would choose as the traget 
#                  Type : int
#       mu: the weights of pulling terms in the same set and pushing terms in the different set.
#                  Type : float or double
#       k_for_kNN: the k value in the KNN
#                  Type : int
#       alpha: the learning rate of the metric learning
#                  Type : float or double
#       max_iter: the number of iteration
#                  Type : int
#
# Additional arguments of Re-ranking
#       rerank_k1: the number of the k-reciprocal neighbour 
#                  Type : int
#       expansion_k2: the parameters for expandeding by the k-nearest neighbors
#                  Type : int
#       lambda_value: the weights of original distance
#                  Type : floar or double
########################################################
print('################# Lmnn_plus_Re-ranking Algorithm #################')
options_lmnn = {'num_traget' : 5, 
               'max_iter' : 2,
               'alpha' : 0.045,
               'mu' : 0.5,
               'k_for_kNN' : 10}

options_rerank = {'rerank_k1' : 10,
                 'expansion_k2' : 5,
                 'lambda_value' : 0.7} 

score_lmnn_re, M_A_P_lmnn_re, Time_consume_lmnn_re = \
Re_ranking_Lmnn(cam_label, gallery_idx, labels, query_idx, \
                train_idx, features, options_lmnn, options_rerank)

print('M_A_P_lmnn_re = ', M_A_P_lmnn_re)
print('Time_consume_lmnn_re = ', Time_consume_lmnn_re)

rank_num = np.arange(10)
rank_socre = np.mean(score_lmnn_re, 0)
print('rank_score_Ma_Lmnn_Re = ', rank_socre)
plt.figure(5)
plt.grid()
plt.plot(rank_num + 1,rank_socre, '-o',         rank_num + 1, rank_socre_base, '-o')
plt.title('@rank_K comparison: LMNN+Re-ranking and KNN baseline')
plt.xlabel('K')
plt.ylabel('rank')
