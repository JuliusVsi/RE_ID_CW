import json
import time
import warnings
import numpy as np
from scipy.io import loadmat
import matplotlib.pyplot as plt
np.set_printoptions(edgeitems = 6)

def KNN_baseline(cam_label, gallery_idx, labels, query_idx, train_idx, features):
    [gallery_M, gallery_N] = gallery_idx.shape
    [train_M, train_N] = train_idx.shape
    [query_M, query_N] = query_idx.shape
    [fea_M, fea_N] = features.shape
    
    # generate the features mat of the training set
    tra_fea = features[train_idx.flatten(), :]

    # generate the features mat of the gallery set
    gallery_features = features[gallery_idx.flatten(), :]

    # generate the features mat of the query set
    query_features = features[query_idx.flatten(), :] 
    
    #################### hyperparameters ####################
    k_for_kNN = 10

    #################### Initialization ####################
    euc_metric = np.eye(fea_N)
    rank_mat = np.zeros((k_for_kNN, 1))
    score = np.zeros((query_M, k_for_kNN))
    precision = np.zeros((k_for_kNN, 1))
    recall = np.zeros((k_for_kNN, 1))
    max_precision = np.zeros((k_for_kNN + 1, 1))
    ave_precision = np.zeros((query_M, 1))
    
    #################### KNN by euc distance ####################
    print('Calculating the distance......')
    gal_labels = labels[gallery_idx.flatten()].flatten()

    Start_time = time.time()
    image_fea = np.vstack((query_features, gallery_features))
    temp = (np.dot(image_fea,euc_metric) * image_fea).sum(axis=1, keepdims=True)
    distance_mat = temp\
      -2 * (np.dot(np.dot(image_fea,euc_metric), image_fea.T)) + temp.T
    distance_mat = distance_mat[: query_M, query_M :]
    dis_idx = np.argsort(distance_mat, 1)

    print('Evaluating......')
    correct_sum = 0
    for image_idx in range(query_M):
        i = 0
        # print('image_idx = ',image_idx, 'correct_sum = ', correct_sum)
        for idx in dis_idx[image_idx, :]:
            if labels[gallery_idx[idx]] != labels[query_idx[image_idx]]:
                rank_mat[i] = labels[gallery_idx[idx]]
                i += 1
            else:
                if cam_label[gallery_idx[idx]] != \
                cam_label[query_idx[image_idx]]:
                    rank_mat[i] = labels[gallery_idx[idx]]
                    i += 1
            if i >= k_for_kNN:
                break
        # evaluation
        max_precision[:,:] = 0
        position_temp =\
        np.array(np.where(gal_labels == labels[query_idx[image_idx]].\
                          flatten())).flatten()
        true_num_in_gal = 0
        for pos in position_temp:
            if cam_label[gallery_idx[pos]] != cam_label[query_idx[image_idx]]:
                true_num_in_gal += 1
        correct_sum = 0
        if true_num_in_gal != 0:
            for i in range(k_for_kNN):
                if rank_mat[i, 0] == labels[query_idx[image_idx]]:
                    score[image_idx, i:] = 1
                    correct_sum += 1
                recall[i] = correct_sum / true_num_in_gal
                precision[i, 0] = correct_sum / (i + 1)
            j = 0
            while j <= 10:
                temp = np.array(np.where(recall.flatten() >= (j / 10))).flatten()
                if temp.size != 0:
                    max_precision[j] = np.max(precision[temp])
                j = j + 1
            ave_precision[image_idx, 0] = np.mean(max_precision)
        else:
            score[image_idx, :] = 0
            ave_precision[image_idx, 0] = 0
    End_time = time.time()
    print('Completed!')
    Time_consume = End_time - Start_time
    M_A_P = np.mean(ave_precision)
    
    return score, M_A_P, Time_consume
