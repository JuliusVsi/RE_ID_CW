import json
import time
import warnings
import numpy as np
from scipy.io import loadmat
np.set_printoptions(edgeitems = 6)



def LMNN_Metric_Learning(cam_label, gallery_idx, labels,\
                        query_idx, train_idx, features, options_lmnn):
    #################### hyperparameters ####################
    num_traget = options_lmnn['num_traget']             # the number of the necessary neighbour
    max_iter = options_lmnn['max_iter']                 # maximum number of iterations
    alpha = options_lmnn['alpha']                       # learning rate
    mu = options_lmnn['mu']                             # weights of pull and push terms
    #########################################################


    [gallery_M, gallery_N] = gallery_idx.shape
    [train_M, train_N] = train_idx.shape
    [query_M, query_N] = query_idx.shape
    [fea_M, fea_N] = features.shape
    labellist = np.unique(labels)
    num_class = len(labellist)

    print('Processing the data......')
    #################### initialization ####################
    met_learned = np.eye(fea_N)            # initialize a metric as the start metric
    final_metric = met_learned
    loss = np.inf                          # set the value of the error is infinite
    final_loss = np.inf

    # generate the features mat of the training set
    tra_fea = features[train_idx.flatten(), :]

    # generate the features mat of the gallery set
    gallery_features = features[gallery_idx.flatten(), :]

    # generate the features mat of the query set
    query_features = features[query_idx.flatten(), :] 
    
    # generate the label matrix for the training set
    label_mat = np.zeros((train_M, num_class))
    for i in range(train_M):
        label_mat[i, labels[train_idx[i]] - 1] = 1

    tra_same_mat = np.dot(label_mat, label_mat.T).astype(int)

    #################### select the traget neigbours ####################
    # compute the pairwise distances
    temp = (tra_fea ** 2).sum(axis=1, keepdims=True)
    tra_dis_mat = temp -2 * np.dot(tra_fea, tra_fea.T) + temp.T

    # replace the distance between self and different classes as inf 
    tra_dis_mat[tra_same_mat == 0] = np.inf
    tra_dis_mat[np.arange(train_M), np.arange(train_M)] = np.inf

    # sort the nearest neigbours and generate a traget matrix by it
    traget_idx = np.argsort(tra_dis_mat, 1)
    traget_idx = traget_idx[:, :num_traget]
    traget_mat = np.zeros((train_M, train_M))

    temp_idx = np.tile(np.arange(train_M).reshape(-1, 1),(num_traget, 1))
    temp = traget_idx.T.reshape(-1, 1)
    traget_mat[temp_idx, temp] = 1

    #################### learning the distance metric ####################
    # Compute pulling term between target neigbhors to initialize gradient
    slack = np.zeros((train_M, train_M, num_traget))
    gradient = np.zeros((fea_N, fea_N))             # initialize the gradient
    for i in range(num_traget):
        temp = tra_fea - tra_fea[traget_idx[:, i], :]
        gradient = gradient + (1 - mu) * np.dot(temp.T, temp)

    num_iter = 0
    tra_dis_mat_orig = tra_dis_mat
    while num_iter < max_iter:
    # compute the pairwise distances under the current metric
        temp = (np.dot(tra_fea,met_learned) * tra_fea).sum(axis=1, keepdims=True)
        tra_dis_mat = temp\
        -2 * (np.dot(np.dot(tra_fea,met_learned), tra_fea.T)) + temp.T
    
    # compute the value of slack variables
        slack_last = slack
        for i in range(num_traget):
            temp = 1 + tra_dis_mat[np.arange(train_M).reshape(-1, 1),\
                        traget_idx[:, i].reshape(-1, 1)] - tra_dis_mat;
            temp[temp < 0] = 0
            slack[:, :, i] = (1 - tra_same_mat) * temp
        print('Computing the slacks is Done')
    
    # Compute value of loss function
        loss_last = loss
        loss = (1 - mu) * np.sum(tra_dis_mat[traget_mat == 1])\
        + mu * np.sum(slack.flatten())
        
    # if the loss becomes smaller, update the metric and the final loss
        if loss < final_loss:
            final_loss = loss
            final_metric = met_learned
    
    # backward propagation 
        for i in range(num_traget):
            # find the position of the new violations
            temp_idx = np.array(np.where(slack[:, :, i].flatten() > 0))
            temp_idx_last = np.array(np.where(slack_last[:, :, i].flatten() == 0))
            vio_idx = np.intersect1d(temp_idx, temp_idx_last).reshape(-1, 1)
            if vio_idx.size != 0:
            # transfer to the row and column index
                r_idx = (vio_idx // train_M).flatten() 
                c_idx = (vio_idx - train_M  * (vio_idx // train_M)).flatten()
                temp = \
                (tra_fea[r_idx, :] - tra_fea[traget_idx[r_idx, i], :])\
                .reshape(1, -1)
                temp_2 = tra_fea[r_idx, :] - tra_fea[c_idx, :]
                gradient = gradient +\
                mu * (np.dot(temp.T, temp) - np.dot(temp_2.T, temp_2))
        
            # find the position of the old violations that should be removed
            temp_idx = np.array(np.where(slack[:, :, i].flatten() == 0))
            temp_idx_last = np.array(np.where(slack_last[:, :, i].flatten() > 0))
            vio_idx = np.intersect1d(temp_idx, temp_idx_last).reshape(-1, 1)
            if vio_idx.size != 0:
                # transfer to the row and column index
                r_idx = (vio_idx // train_M).flatten() 
                c_idx = (vio_idx - train_M  * (vio_idx // train_M)).flatten()
                temp = \
                (tra_fea[r_idx, :] - tra_fea[traget_idx[r_idx, i], :])\
                .reshape(1, -1)
                temp_2 = tra_fea[r_idx, :] - tra_fea[c_idx, :]
                gradient = gradient -\
                mu * (np.dot(temp.T, temp) - np.dot(temp_2.T, temp_2))      
        print('Backward calculation completed!')
        # update the learned metric  
        met_learned = met_learned - (alpha / train_M) * gradient
    
        # identify whether the learned metric is semi-positive
        eigval, eigvec = np.linalg.eig(met_learned)
        eigval = np.real(eigval)
        eigvec = np.real(eigvec)
        pos_idx = np.array(np.where(eigval > 0)).flatten()
        # identify wheather the positive eigenvalues exist
        if pos_idx.size == 0:
            warnings.warn('Warning message: All eigenvalues were negative')
            break
    
        # project metric back onto the PSD cone
        temp_eigval = np.eye(pos_idx.size)
        temp_eigval[np.arange(pos_idx.size), np.arange(pos_idx.size)] = \
        eigval[pos_idx]
        met_learned = \
        np.dot(np.dot(eigvec[:, pos_idx], temp_eigval), eigvec[:, pos_idx].T)
    
        # identify wheather infinitive numbers exist
        if np.isinf(met_learned).any():
            warnings.warn('Warning message: Infinitive numbers exist')
            break
        # identify wheather NaN values exist  
        if np.isnan(met_learned).any():
            warnings.warn('Warning message: NaN values exist')
            break 
        
    
        # update the learning rate to improve the convergence property
        if loss_last > loss:
            alpha = alpha * 1.01 
        else:
            alpha = alpha * 0.2
    
        # print the progress
        no_slack = np.sum((slack > 0))
        print('iteration = ', num_iter, 'loss', loss, 'no_slack = ', no_slack)
        num_iter += 1

    print('Metric Learning is done! Re-Identification by KNN......')
    #################### hyperparameters ####################
    k_for_kNN = options_lmnn['k_for_kNN']

    #################### Initialization ####################
    rank_mat = np.zeros((k_for_kNN, 1))
    score = np.zeros((query_M, k_for_kNN))
    precision = np.zeros((k_for_kNN, 1))
    recall = np.zeros((k_for_kNN, 1))
    max_precision = np.zeros((k_for_kNN + 1, 1))
    ave_precision = np.zeros((query_M, 1))

    #################### KNN by this learned metric ####################
    gal_labels = labels[gallery_idx.flatten()].flatten()

    Start_time = time.time()
    image_fea = np.vstack((query_features, gallery_features))
    temp = (np.dot(image_fea,final_metric) * image_fea).sum(axis=1, keepdims=True)
    distance_mat = temp\
    -2 * (np.dot(np.dot(image_fea,final_metric), image_fea.T)) + temp.T
    distance_mat = distance_mat[: query_M, query_M :]
    dis_idx = np.argsort(distance_mat, 1)

    correct_sum = 0
    for image_idx in range(query_M):
        i = 0
        # print('image_idx = ',image_idx, 'correct_sum = ', correct_sum)
        for idx in dis_idx[image_idx, :]:
            if labels[gallery_idx[idx]] != labels[query_idx[image_idx]]:
                rank_mat[i] = labels[gallery_idx[idx]]
                i += 1
            else:
                if cam_label[gallery_idx[idx]] != \
                cam_label[query_idx[image_idx]]:
                    rank_mat[i] = labels[gallery_idx[idx]]
                    i += 1
            if i >= k_for_kNN:
                break
        # evaluation
        max_precision[:,:] = 0
        position_temp =\
        np.array(np.where(gal_labels == labels[query_idx[image_idx]].\
                        flatten())).flatten()
        true_num_in_gal = 0
        for pos in position_temp:
            if cam_label[gallery_idx[pos]] != cam_label[query_idx[image_idx]]:
                true_num_in_gal += 1
        correct_sum = 0
        if true_num_in_gal != 0:
            for i in range(k_for_kNN):
                if rank_mat[i, 0] == labels[query_idx[image_idx]]:
                    score[image_idx, i:] = 1
                    correct_sum += 1
                recall[i] = correct_sum / true_num_in_gal
                precision[i, 0] = correct_sum / (i + 1)
            j = 0
            while j <= 10:
                temp = np.array(np.where(recall.flatten() >= (j / 10))).flatten()
                if temp.size != 0:
                    max_precision[j] = np.max(precision[temp])
                j = j + 1
            ave_precision[image_idx, 0] = np.mean(max_precision)
        else:
            score[image_idx, :] = 0
            ave_precision[image_idx, 0] = 0
    End_time = time.time()
    Time_consume = End_time - Start_time        
    Rank_1 = np.mean(score[:,0])
    Rank_5 = np.mean(score[:,4])
    Rank_10 = np.mean(score[:,9])
    M_A_P = np.mean(ave_precision)
    return score, M_A_P, Time_consume