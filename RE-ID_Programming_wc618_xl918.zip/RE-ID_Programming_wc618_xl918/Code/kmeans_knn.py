import json
import time
import warnings
import numpy as np
from scipy.io import loadmat
np.set_printoptions(edgeitems = 6)

############################ initialization ############################
# function name: get_initial_cluster_centers
# arguments: 'data' refers to the test data
#            'k' refers to the number of the initial cluster centers
#            'num_feature' refers to the number of features belonging to
#            each data point.
#            'seed' refers to the seed of the randomization, the reason
#            why this atgument is necessary is because when we debug the
#            programme, we hope to obtain the same initial centers each time
#######################################################################
def get_initial_cluster_centers(k, num_feature, seed=None):
    if seed != None:
        np.random.seed(seed)
    centers_mat = np.random.randn(k, num_feature)
    return centers_mat


def KNN_KMEANS(cam_label, gallery_idx, labels, \
               query_idx, train_idx, features, num_classes, seed=None):
    [gallery_M, gallery_N] = gallery_idx.shape
    [train_M, train_N] = train_idx.shape
    [query_M, query_N] = query_idx.shape
    [fea_M, fea_N] = features.shape
    labellist = np.unique(labels)
    num_class = len(labellist)
    # generate the features mat of the gallery set
    gallery_features = features[gallery_idx.flatten(), :]

    # generate the features mat of the query set
    query_features = features[query_idx.flatten(), :] 

    # Using identity matrix as the metric to 
    # calculate the Euclidean distance 
    iden_metric = np.eye(fea_N)

    #############################################
    #hyperparameters
    max_iter = 200
    #############################################
    centers = get_initial_cluster_centers(num_classes, fea_N, seed)
    centers_record = np.zeros((num_classes, fea_N, max_iter + 1))
    centers_record[:, :, 0] = \
    get_initial_cluster_centers(num_classes, fea_N, seed)
    print('Clustering......')
    #################### Kmeans ####################
    num_iter = 0
    for num_iter in range(max_iter):
        image_fea = np.vstack((gallery_features, centers))
        temp = (np.dot(image_fea,iden_metric) * image_fea)\
        .sum(axis=1, keepdims=True)
        distance_mat = temp\
          -2 * (np.dot(np.dot(image_fea,iden_metric), image_fea.T)) \
        + temp.T
        distance_mat = distance_mat[: gallery_M, gallery_M :]
        dis_idx = np.argsort(distance_mat, 1)
        K_means_idx = dis_idx[:, 0].reshape(-1, 1)
        for num_class in range(num_classes):
            temp = (K_means_idx == num_class)
            fea_sum = \
            (gallery_features * np.tile(temp,(1, fea_N)))\
            .sum(axis=0, keepdims=True)\
            + centers[num_class, :].reshape(1, fea_N)
            centers[num_class, :] = fea_sum / (np.sum(temp) + 1)
        centers_record[:, :, num_iter + 1] = centers
        if np.all(abs(centers_record[:, :, num_iter + 1] \
                      - centers_record[:, :, num_iter]) < 1e-5):
            print('Clustering Completed!')
            break


    #################### hyperparameters ####################
    k_for_kNN = 10

    #################### Initialization ####################
    euc_metric = np.eye(fea_N)
    rank_mat = np.zeros((k_for_kNN, 1))
    score = np.zeros((query_M, k_for_kNN))
    precision = np.zeros((k_for_kNN, 1))
    recall = np.zeros((k_for_kNN, 1))
    max_precision = np.zeros((k_for_kNN + 1, 1))
    ave_precision = np.zeros((query_M, 1))

    #################### KNN + Kmeans ####################
    gal_labels = labels[gallery_idx.flatten()].flatten()

    Start_time = time.time()

    num_iter = 0
    for image_idx in query_idx:
        image_fea = features[image_idx, :].reshape(1, -1)
        # identify which class the image belong to which class
        dis_bet_class = np.sqrt(((image_fea - centers) ** 2).sum(axis=1)) 
        dis_bet_class_idx = np.argsort(dis_bet_class, 0)
        # generate the features matrix of the corresponding image
        cor_gal_idx = gallery_idx[K_means_idx == dis_bet_class_idx[0]]
        cor_fea = features[cor_gal_idx]
        # calculate the distance between each image 
        # in the corresponding image
        dis_mat = np.sqrt(((image_fea - cor_fea) ** 2).sum(axis=1)) 
        dis_idx = np.argsort(dis_mat, 0)
        i = 0
        for idx in dis_idx:
            if labels[cor_gal_idx[idx]] != labels[image_idx]:
                rank_mat[i] = labels[cor_gal_idx[idx]]
                i += 1
            else:
                if cam_label[cor_gal_idx[idx]] != \
                cam_label[image_idx]:
                    rank_mat[i] = labels[cor_gal_idx[idx]]
                    i += 1
            if i >= k_for_kNN:
                break
        # evaluation
        max_precision[:,:] = 0
        position_temp =\
        np.array(np.where(gal_labels == labels[image_idx]\
                          .flatten())).flatten()
        true_num_in_gal = 0
        for pos in position_temp:
            if cam_label[gallery_idx[pos]] != cam_label[image_idx]:
                true_num_in_gal += 1
        correct_sum = 0
        if true_num_in_gal != 0:
            for i in range(k_for_kNN):
                if rank_mat[i, 0] == labels[image_idx]:
                    score[num_iter, i:] = 1
                    correct_sum += 1
                recall[i] = correct_sum / true_num_in_gal
                precision[i, 0] = correct_sum / (i + 1)
            j = 0
            while j <= 10:
                temp = \
                np.array(np.where(recall.flatten() >= (j / 10))).flatten()
                if temp.size != 0:
                    max_precision[j] = np.max(precision[temp])
                j = j + 1
            ave_precision[num_iter, 0] = np.mean(max_precision)
        else:
            score[num_iter, :] = 0
            ave_precision[num_iter, 0] = 0
        num_iter += 1
    End_time = time.time()
    Time_consume = End_time - Start_time
    M_A_P = np.mean(ave_precision)

    return score, M_A_P, Time_consume